package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Passwords
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-01-09T17:13:11.506Z")

public class Passwords   {
  @JsonProperty("oldpassword")
  private String oldpassword = null;

  @JsonProperty("newpassword")
  private String newpassword = null;

  public Passwords oldpassword(String oldpassword) {
    this.oldpassword = oldpassword;
    return this;
  }

  /**
   * Get oldpassword
   * @return oldpassword
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getOldpassword() {
    return oldpassword;
  }

  public void setOldpassword(String oldpassword) {
    this.oldpassword = oldpassword;
  }

  public Passwords newpassword(String newpassword) {
    this.newpassword = newpassword;
    return this;
  }

  /**
   * Get newpassword
   * @return newpassword
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getNewpassword() {
    return newpassword;
  }

  public void setNewpassword(String newpassword) {
    this.newpassword = newpassword;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Passwords passwords = (Passwords) o;
    return Objects.equals(this.oldpassword, passwords.oldpassword) &&
        Objects.equals(this.newpassword, passwords.newpassword);
  }

  @Override
  public int hashCode() {
    return Objects.hash(oldpassword, newpassword);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Passwords {\n");
    
    sb.append("    oldpassword: ").append(toIndentedString(oldpassword)).append("\n");
    sb.append("    newpassword: ").append(toIndentedString(newpassword)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

