package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Player
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-12-28T15:53:43.255Z")

public class Player   {
  @JsonProperty("id")
  private String id = null;

  @JsonProperty("password")
  private String password = null;

  @JsonProperty("strength")
  private Integer strength = null;

  @JsonProperty("dexterity")
  private Integer dexterity = null;

  @JsonProperty("constitution")
  private Integer constitution = null;

  @JsonProperty("intelligence")
  private Integer intelligence = null;

  @JsonProperty("wisdom")
  private Integer wisdom = null;

  @JsonProperty("charisma")
  private Integer charisma = null;

  @JsonProperty("fkRace")
  private String fkRace = null;

  @JsonProperty("fkClasse")
  private String fkClasse = null;

  public Player id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(value = "")


  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public Player password(String password) {
    this.password = password;
    return this;
  }

  /**
   * Get password
   * @return password
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public Player strength(Integer strength) {
    this.strength = strength;
    return this;
  }

  /**
   * Get strength
   * @return strength
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Integer getStrength() {
    return strength;
  }

  public void setStrength(Integer strength) {
    this.strength = strength;
  }

  public Player dexterity(Integer dexterity) {
    this.dexterity = dexterity;
    return this;
  }

  /**
   * Get dexterity
   * @return dexterity
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Integer getDexterity() {
    return dexterity;
  }

  public void setDexterity(Integer dexterity) {
    this.dexterity = dexterity;
  }

  public Player constitution(Integer constitution) {
    this.constitution = constitution;
    return this;
  }

  /**
   * Get constitution
   * @return constitution
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Integer getConstitution() {
    return constitution;
  }

  public void setConstitution(Integer constitution) {
    this.constitution = constitution;
  }

  public Player intelligence(Integer intelligence) {
    this.intelligence = intelligence;
    return this;
  }

  /**
   * Get intelligence
   * @return intelligence
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Integer getIntelligence() {
    return intelligence;
  }

  public void setIntelligence(Integer intelligence) {
    this.intelligence = intelligence;
  }

  public Player wisdom(Integer wisdom) {
    this.wisdom = wisdom;
    return this;
  }

  /**
   * Get wisdom
   * @return wisdom
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Integer getWisdom() {
    return wisdom;
  }

  public void setWisdom(Integer wisdom) {
    this.wisdom = wisdom;
  }

  public Player charisma(Integer charisma) {
    this.charisma = charisma;
    return this;
  }

  /**
   * Get charisma
   * @return charisma
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Integer getCharisma() {
    return charisma;
  }

  public void setCharisma(Integer charisma) {
    this.charisma = charisma;
  }

  public Player fkRace(String fkRace) {
    this.fkRace = fkRace;
    return this;
  }

  /**
   * Get fkRace
   * @return fkRace
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getFkRace() {
    return fkRace;
  }

  public void setFkRace(String fkRace) {
    this.fkRace = fkRace;
  }

  public Player fkClasse(String fkClasse) {
    this.fkClasse = fkClasse;
    return this;
  }

  /**
   * Get fkClasse
   * @return fkClasse
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getFkClasse() {
    return fkClasse;
  }

  public void setFkClasse(String fkClasse) {
    this.fkClasse = fkClasse;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Player player = (Player) o;
    return Objects.equals(this.id, player.id) &&
        Objects.equals(this.password, player.password) &&
        Objects.equals(this.strength, player.strength) &&
        Objects.equals(this.dexterity, player.dexterity) &&
        Objects.equals(this.constitution, player.constitution) &&
        Objects.equals(this.intelligence, player.intelligence) &&
        Objects.equals(this.wisdom, player.wisdom) &&
        Objects.equals(this.charisma, player.charisma) &&
        Objects.equals(this.fkRace, player.fkRace) &&
        Objects.equals(this.fkClasse, player.fkClasse);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, password, strength, dexterity, constitution, intelligence, wisdom, charisma, fkRace, fkClasse);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Player {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    password: ").append(toIndentedString(password)).append("\n");
    sb.append("    strength: ").append(toIndentedString(strength)).append("\n");
    sb.append("    dexterity: ").append(toIndentedString(dexterity)).append("\n");
    sb.append("    constitution: ").append(toIndentedString(constitution)).append("\n");
    sb.append("    intelligence: ").append(toIndentedString(intelligence)).append("\n");
    sb.append("    wisdom: ").append(toIndentedString(wisdom)).append("\n");
    sb.append("    charisma: ").append(toIndentedString(charisma)).append("\n");
    sb.append("    fkRace: ").append(toIndentedString(fkRace)).append("\n");
    sb.append("    fkClasse: ").append(toIndentedString(fkClasse)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

